# CrowPanel P4 v3.x Demo - ES8311 / ES7210

For the new audio batch with ESP32-P4 v3.1/v3.2 silicon, ES8311 DAC,
ES7210 ADC and NS4263B amplifier; 1024x600 display.
Not for P4 v1.x silicon or boards with the legacy audio hardware.

Extract the entire ZIP. Keep the EXE, _internal and firmware together.
Connect UART0 USB-C, close serial applications, run CrowPanel_P4_fast_flasher.exe,
select the COM port and click Flash panel. Clean install erases all flash and
saved settings; leave it unchecked when updating the previous compatible demo.
Wait for success, then fully disconnect power and reconnect.

This is the normal Demo UI. The temporary audio diagnostic application and
startup microphone test have been removed from source, not merely disabled.
The Demo does not offer microphone recording.

Audio changes:
1. Added ES8311/ES7210 support over I2C and shared 16 kHz I2S clocks.
2. Corrected NS4263B amplifier control: GPIO30 low enables output. Added initial
   shutdown timing. The diagnostic test firmware was reported working by the tester.

This normal-Demo build completed with ESP-IDF 5.5.4; its own panel validation
is pending. Check display/touch, both speakers, volume/mute and cold restart.
For issues, send a full UART0 log at 115200 baud and a short video.
The Windows flasher is reused unchanged from the previous diagnostic package.
SHA256SUMS.txt covers all other files in this package.
