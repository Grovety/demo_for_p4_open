# CrowPanel HW1.3 / ESP32-P4 V1.x Demo
This package uses the display startup settings from the successfully tested
color-probe firmware, with the color sequence disabled. This new binary still
requires a cold-boot check on the target panel.

Extract the entire ZIP. Connect UART0 USB-C, run CrowPanel_P4_fast_flasher.exe,
select the COM port and click Flash panel. Clean install erases saved settings.
After flashing, fully disconnect power and reconnect it.
Expect the normal Demo UI directly. Check touch, sound and brightness.
If behavior differs, send the full UART0 startup log at 115200 baud and a video.

Silicon range: v1.0-v1.99. CPU 360 MHz, PSRAM 200 MHz. Legacy audio hardware.
LDO3/LDO4 are enabled before LCD startup, followed by 400 ms settling,
GT911 initialization and EK79007 initialization.
Use the bootloader, partition table and app from this package together.
