# CrowPanel HW V1.3 — Demo for P4 v1.0

Windows installation package for CrowPanel Advanced ESP32-P4 9-inch and
10.1-inch HW V1.3 panels with 1024x600 displays.

## Compatibility

This candidate targets ESP32-P4 silicon v3.1/v3.2 (minimum v3.1).
HW V1.3 is the PCB version, not the processor revision. Confirm the processor
revision from the existing working firmware's flashing/boot log before use.
Do not use on P4 v1.x, 5-inch 800x480 panels, or older PCB revisions.

Firmware: ESP-IDF v5.5.4, RGB565, 51 MHz pixel clock, 900 Mbps per DSI lane,
LCD reset GPIO41, backlight GPIO31. This is an experimental test candidate;
it has compiled successfully but has not been validated on HW V1.3.
The existing Windows EXE is reused unchanged (bundled esptool 5.3.1).
Its launch and flashing with this package still require Windows/device testing.

## Install on Windows

1. Fully extract the ZIP into a short local path, for example C:\CrowPanel13.
2. Confirm that this panel has P4 silicon v3.1/v3.2.
3. Connect the UART0 USB-C port with a data-capable USB cable.
4. Close other applications using the COM port.
5. Run CrowPanel_P4_fast_flasher.exe from the extracted folder.
6. Select the COM port; use Refresh if necessary.
7. For this first test over the previous firmware, enable Clean install
   (erase entire flash). This deletes the previous P4 firmware and settings;
   keep its recovery package available before proceeding.
8. Click Flash panel and wait for Firmware installed successfully.
9. Do not disconnect power during installation. The panel restarts afterward.

Keep the EXE, _internal directory and firmware directory together.
The GUI success message confirms installation, not LCD acceptance.

## Tester feedback

Test the 9-inch and 10.1-inch panels separately. Report PCB and chip revisions,
complete UART0 boot output at 115200 baud, whether the backlight illuminates,
a photo of the image, colors, touch at all corners, brightness adjustment,
and behavior after a power cycle. Check animations and audio together.
Do not bypass chip-revision errors or force flashing on an unsupported chip.

## Firmware map

- 0x2000: firmware/bootloader.bin
- 0x8000: firmware/partition-table.bin
- 0x10000: firmware/Demo_for_P4.bin
- Flash: DIO, 80 MHz, 16 MB

All three binaries come from one build-v1.3-p4v3 build. Do not mix binaries.
See package-info.json and SHA256SUMS.txt for exact package provenance.
