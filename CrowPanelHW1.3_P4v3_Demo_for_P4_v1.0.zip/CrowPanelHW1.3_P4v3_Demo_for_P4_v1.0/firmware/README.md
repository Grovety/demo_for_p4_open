Firmware files from one ESP-IDF 5.5.4 build. See ../README.md for compatibility and installation.
