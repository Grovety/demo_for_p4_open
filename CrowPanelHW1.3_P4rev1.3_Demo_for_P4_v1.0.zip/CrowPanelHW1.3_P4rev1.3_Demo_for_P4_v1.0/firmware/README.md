Firmware from one user-built ESP-IDF 5.5.4 build for HW V1.3 and P4 silicon v1.3. See ../README.md.
