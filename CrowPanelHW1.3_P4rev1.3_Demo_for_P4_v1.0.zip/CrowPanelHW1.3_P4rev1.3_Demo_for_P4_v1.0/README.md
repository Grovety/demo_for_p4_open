# CrowPanel HW V1.3 — P4 silicon v1.3 — Demo for P4 v1.0

Windows installation package for CrowPanel Advanced ESP32-P4 9-inch and
10.1-inch HW V1.3 panels, 1024x600, with ESP32-P4 silicon v1.3.
The image revision range is v1.0–v1.99; the requested device is v1.3.
PCB revision and processor revision are separate. Confirm both before use.
Do not use this package on P4 v3.x, 5-inch panels, or earlier PCB revisions.

Built manually by the user with ESP-IDF 5.5.4 from source commit 0b9e8fb.
Compilation succeeded; Windows launch and hardware operation remain untested.
LCD: RGB565, 51 MHz pixel clock, 900 Mbps per DSI lane, reset GPIO41,
backlight GPIO31. CPU: 360 MHz. PSRAM: 200 MHz.
The existing Windows flasher EXE and its runtime are reused unchanged.

## Installation

1. Fully extract the ZIP into a short local path, for example C:\CrowPanel13.
2. Confirm HW V1.3 and ESP32-P4 silicon v1.3 from the board and boot/flash log.
3. Connect UART0 USB-C with a data cable and close applications using the COM port.
4. Run CrowPanel_P4_fast_flasher.exe and select the COM port.
5. When replacing unrelated firmware, enable Clean install (erase entire flash).
   This deletes previous firmware and settings; retain its recovery package.
6. Click Flash panel and wait for Firmware installed successfully.
7. Keep power connected throughout installation. The panel restarts afterward.

Keep the EXE, _internal and firmware directories together.
Do not bypass chip-revision errors or force flashing.

## Manual acceptance

Test the 9-inch and 10.1-inch panels separately. Save the UART0 cold-boot log
at 115200 baud and confirm Hardware=V1.3 and the V1.3 LCD initialization.
Check backlight, stable full image, colors, touch at all corners, brightness,
animations with audio, repeated resets and power cycles.
Installation success does not confirm hardware operation.
Wireless GPIO27/28 wiring remains an assumption pending schematic confirmation.

## Firmware map

- 0x2000: firmware/bootloader.bin
- 0x8000: firmware/partition-table.bin
- 0x10000: firmware/Demo_for_P4.bin
- Flash: DIO, 80 MHz, 16 MB

All binaries come from build-v1.3-p4rev13. Do not mix builds.
See package-info.json and SHA256SUMS.txt for provenance and hashes.
